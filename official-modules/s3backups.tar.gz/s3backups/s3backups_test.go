package s3backups

import (
	"strings"
	"testing"
)

func TestS3BackupsOverlayEmbedded(t *testing.T) {
	content, err := files.ReadFile("files/data-overlays/config.yaml")
	if err != nil {
		t.Fatalf("data-overlays/config.yaml not embedded: %v", err)
	}
	if len(content) == 0 {
		t.Fatal("data-overlays/config.yaml is empty")
	}
	for _, key := range []string{"Schedule", "Enabled", "Bucket", "Region", "Prefix", "AccessKey", "SecretKey"} {
		if !strings.Contains(string(content), key) {
			t.Errorf("data-overlays/config.yaml missing key %q", key)
		}
	}
}
