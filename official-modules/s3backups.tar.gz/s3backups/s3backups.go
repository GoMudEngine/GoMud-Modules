package s3backups

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"context"
	"embed"
	"encoding/base64"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/GoMudEngine/GoMud/internal/configs"
	"github.com/GoMudEngine/GoMud/internal/connections"
	"github.com/GoMudEngine/GoMud/internal/events"
	"github.com/GoMudEngine/GoMud/internal/gametime"
	"github.com/GoMudEngine/GoMud/internal/mudlog"
	"github.com/GoMudEngine/GoMud/internal/plugins"
	"github.com/GoMudEngine/GoMud/internal/rooms"
	"github.com/GoMudEngine/GoMud/internal/users"
	"github.com/GoMudEngine/GoMud/internal/util"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

var (

	//////////////////////////////////////////////////////////////////////
	// NOTE: The below //go:embed directive is important!
	// It embeds the relative path into the var below it.
	//////////////////////////////////////////////////////////////////////

	//go:embed files/*
	files embed.FS
)

type backupState struct {
	LastBackupRound uint64 `yaml:"lastbackupround"`
}

type S3BackupsModule struct {
	plug            *plugins.Plugin
	lastBackupRound uint64
}

func init() {
	m := &S3BackupsModule{
		plug: plugins.New(`s3backups`, `1.0`),
	}

	m.plug.Callbacks.SetOnLoad(m.load)
	m.plug.Callbacks.SetOnSave(m.save)

	//
	// Add the embedded filesystem
	//
	if err := m.plug.AttachFileSystem(files); err != nil {
		panic(err)
	}

	m.plug.Web.AdminPage("Config", "s3backups-config", "html/admin/s3backups-config.html", true, "Modules", "s3backups", "Configure backup schedule and Amazon S3 upload settings.", "Automated world backup module creating compressed archives on a configurable schedule with optional S3 upload.", nil)
	m.plug.Web.AdminPage("Backup Guide", "s3backups-docs", "html/admin/s3backups-docs.html", true, "Modules", "s3backups", "Step-by-step guide for configuring backups and Amazon S3.", "", nil)
	m.plug.Web.AdminPage("About", "s3backups-about", "html/admin/s3backups-about.html", true, "Modules", "s3backups", "Information and version details for the s3backups module.", "", nil)

	m.plug.Web.AdminAPIEndpoint("POST", "s3backups/download", m.apiBackupDownload)

	events.RegisterListener(events.NewRound{}, m.onNewRound)
}

func (m *S3BackupsModule) load() {
	var state backupState
	if err := m.plug.ReadIntoStruct("state", &state); err == nil {
		m.lastBackupRound = state.LastBackupRound
	}
}

func (m *S3BackupsModule) save() {
	m.plug.WriteStruct("state", &backupState{LastBackupRound: m.lastBackupRound})
}

func (m *S3BackupsModule) onNewRound(e events.Event) events.ListenerReturn {
	evt, ok := e.(events.NewRound)
	if !ok {
		return events.Continue
	}

	schedule := m.schedule()
	if schedule == `` || schedule == `never` {
		return events.Continue
	}

	period := scheduleToIRLPeriod(schedule)
	if period == `` {
		return events.Continue
	}

	currentRound := evt.RoundNumber

	var nextRound uint64
	if m.lastBackupRound == 0 {
		nextRound = 0
	} else {
		nextRound = gametime.GetDate(m.lastBackupRound).AddPeriod(period)
	}

	if currentRound >= nextRound {
		m.lastBackupRound = currentRound
		go m.runBackup()
	}

	return events.Continue
}

func (m *S3BackupsModule) schedule() string {
	if v, ok := m.plug.Config.Get(`Schedule`).(string); ok {
		return strings.ToLower(strings.TrimSpace(v))
	}
	return ``
}

func scheduleToIRLPeriod(schedule string) string {
	switch schedule {
	case `nightly`:
		return `1 irl day`
	case `weekly`:
		return `7 irl days`
	case `monthly`:
		return `1 irl month`
	}
	return ``
}

func (m *S3BackupsModule) runBackup() {
	connections.Broadcast([]byte("\r\n*** World backup starting — the server will pause briefly. ***\r\n"))

	util.LockMud()

	connections.Broadcast([]byte("Saving world data...\r\n"))
	users.SaveAllUsers()
	rooms.SaveAllRooms()
	plugins.Save()

	connections.Broadcast([]byte("Creating backup archive...\r\n"))
	data, filename, err := createWorldBackup()

	util.UnlockMud()

	if err != nil {
		mudlog.Error("s3backups", "action", "backup failed", "error", err)
		connections.Broadcast([]byte("*** Backup failed. ***\r\n"))
		return
	}

	mudlog.Info("s3backups", "action", "world archive created", "filename", filename, "size", len(data))

	if enabled, ok := m.plug.Config.Get(`Enabled`).(bool); ok && enabled {
		if err := m.uploadToS3(data, filename); err != nil {
			mudlog.Error("s3backups", "action", "S3 upload failed", "error", err)
			connections.Broadcast([]byte("*** Backup S3 upload failed. ***\r\n"))
			return
		}
		mudlog.Info("s3backups", "action", "S3 upload complete", "filename", filename)
	}

	connections.Broadcast([]byte("*** World backup complete. ***\r\n"))
}

func (m *S3BackupsModule) runBackupSync() ([]byte, string, error) {
	connections.Broadcast([]byte("\r\n*** World backup starting — the server will pause briefly. ***\r\n"))

	util.LockMud()

	connections.Broadcast([]byte("Saving world data...\r\n"))
	users.SaveAllUsers()
	rooms.SaveAllRooms()
	plugins.Save()

	connections.Broadcast([]byte("Creating backup archive...\r\n"))
	data, filename, err := createWorldBackup()

	util.UnlockMud()

	if err != nil {
		connections.Broadcast([]byte("*** Backup failed. ***\r\n"))
		return nil, "", err
	}

	connections.Broadcast([]byte("*** World backup complete. ***\r\n"))
	return data, filename, nil
}

func (m *S3BackupsModule) uploadToS3(data []byte, filename string) error {
	accessKey, _ := m.plug.Config.Get(`AccessKey`).(string)
	secretKey, _ := m.plug.Config.Get(`SecretKey`).(string)

	if accessKey == `` || secretKey == `` {
		return fmt.Errorf("S3 access key and secret key must be configured")
	}

	region, _ := m.plug.Config.Get(`Region`).(string)
	if region == `` {
		region = `us-east-1`
	}

	bucket, _ := m.plug.Config.Get(`Bucket`).(string)
	prefix, _ := m.plug.Config.Get(`Prefix`).(string)

	client := s3.New(s3.Options{
		Region:      region,
		Credentials: credentials.NewStaticCredentialsProvider(accessKey, secretKey, ""),
	})

	key := filename
	if p := strings.TrimRight(prefix, "/"); p != "" {
		key = p + "/" + filename
	}

	_, err := client.PutObject(context.Background(), &s3.PutObjectInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		Body:        bytes.NewReader(data),
		ContentType: aws.String("application/gzip"),
	})
	if err != nil {
		return fmt.Errorf("S3 upload: %w", err)
	}

	return nil
}

func (m *S3BackupsModule) apiBackupDownload(r *http.Request) (int, bool, any) {
	data, filename, err := m.runBackupSync()
	if err != nil {
		return http.StatusInternalServerError, false, "backup failed: " + err.Error()
	}

	m.lastBackupRound = util.GetRoundCount()

	if enabled, ok := m.plug.Config.Get(`Enabled`).(bool); ok && enabled {
		if err := m.uploadToS3(data, filename); err != nil {
			mudlog.Error("s3backups", "action", "S3 upload failed", "error", err)
		} else {
			mudlog.Info("s3backups", "action", "S3 upload complete", "filename", filename)
		}
	}

	return http.StatusOK, true, map[string]any{
		"filename": filename,
		"size":     len(data),
		"data":     base64.StdEncoding.EncodeToString(data),
	}
}

func backupFilename() string {
	return fmt.Sprintf("world-backup-%s.tar.gz", time.Now().UTC().Format("2006-01-02-150405"))
}

func createWorldBackup() ([]byte, string, error) {
	dataFiles := configs.GetFilePathsConfig().DataFiles.String()

	var buf bytes.Buffer
	gz := gzip.NewWriter(&buf)
	tw := tar.NewWriter(gz)

	baseDir := filepath.Clean(dataFiles)

	err := filepath.Walk(baseDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		relPath, err := filepath.Rel(baseDir, path)
		if err != nil {
			return err
		}

		header, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return err
		}
		header.Name = filepath.ToSlash(relPath)

		if err := tw.WriteHeader(header); err != nil {
			return err
		}

		if info.IsDir() {
			return nil
		}

		f, err := os.Open(path)
		if err != nil {
			return err
		}
		defer f.Close()

		_, err = io.Copy(tw, f)
		return err
	})

	if err != nil {
		tw.Close()
		gz.Close()
		return nil, "", fmt.Errorf("creating tar archive: %w", err)
	}

	if err := tw.Close(); err != nil {
		gz.Close()
		return nil, "", fmt.Errorf("closing tar writer: %w", err)
	}
	if err := gz.Close(); err != nil {
		return nil, "", fmt.Errorf("closing gzip writer: %w", err)
	}

	filename := backupFilename()
	return buf.Bytes(), filename, nil
}
